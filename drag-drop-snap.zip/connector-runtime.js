class ConnectorRuntimeExtension extends Autodesk.Viewing.Extension {
    constructor(viewer, options) {
        super(viewer, options);
        this._connectors = [];
        this._onCameraChange = this.onCameraChange.bind(this);
        this._onModelChange = this.onModelChange.bind(this);
        this._connectorGeometry = new THREE.SphereGeometry(options.connectorSize || 0.5, 4, 4);
        this._connectorMaterial = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
    }

    load() {
        this.viewer.addEventListener(Autodesk.Viewing.CAMERA_CHANGE_EVENT, this._onCameraChange);
        this.viewer.addEventListener(Autodesk.Viewing.HIDE_EVENT, this._onModelChange);
        this.viewer.addEventListener(Autodesk.Viewing.SHOW_EVENT, this._onModelChange);
        this.viewer.addEventListener(Autodesk.Viewing.ISOLATE_EVENT, this._onModelChange);
        this.viewer.overlays.addScene('connectors');
        console.log('Connectors extension loaded.');
        return true;
    }

    unload() {
        this.viewer.removeEventListener(Autodesk.Viewing.CAMERA_CHANGE_EVENT, this._onCameraChange);
        this.viewer.removeEventListener(Autodesk.Viewing.HIDE_EVENT, this._onModelChange);
        this.viewer.removeEventListener(Autodesk.Viewing.SHOW_EVENT, this._onModelChange);
        this.viewer.removeEventListener(Autodesk.Viewing.ISOLATE_EVENT, this._onModelChange);
        this.viewer.overlays.removeScene('connectors');
        console.log('Connectors extension unloaded.');
        return true;
    }

    addConnectors(connectors) {
        this._connectors = this._connectors.concat(connectors);
        this.updateOverlay();
        this.updateProjected();
    }

    // Removes connectors associated with specific model
    removeConnectors(model) {
        this._connectors = this._connectors.filter(connector => connector.model !== model);
        this.updateOverlay();
        this.updateProjected();
    }

    updateOverlay() {
        this.viewer.overlays.clearScene('connectors');
        for (const connector of this._connectors) {
            const group = new THREE.Group();
            
            const mesh = new THREE.Mesh(this._connectorGeometry, this._connectorMaterial);
            group.add(mesh);
            
            group.position.setFromMatrixPosition(connector.transform);
            this.viewer.overlays.addMesh(group, 'connectors');
        }
        this.viewer.impl.invalidate(true, false, true);
    }

    updateProjected() {
      for (const connector of this._connectors) {
        const worldPos = new THREE.Vector3();
        worldPos.setFromMatrixPosition(connector.transform);
        connector.screenPos = this.viewer.impl.worldToClient(worldPos);
      }
    }

    onCameraChange() {
        this.updateProjected();
    }

    onModelChange() {
        this.updateOverlay();
        this.updateProjected();
    }

    findNearest(clientX, clientY, maxRadius) {
        let nearest = null;
        let minDist = Number.MAX_VALUE;
        for (let connector of this._connectors) {
            const dx = connector.screenPos.x - clientX;
            const dy = connector.screenPos.y - clientY;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < maxRadius && dist < minDist) {
                nearest = connector;
                minDist = dist;
            }
        }
        return nearest;
    }
}

Autodesk.Viewing.theExtensionManager.registerExtension('ConnectorRuntimeExtension', ConnectorRuntimeExtension);