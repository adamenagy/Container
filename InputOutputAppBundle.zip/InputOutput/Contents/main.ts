import { adsk } from "@adsk/fas";

function run() {
  const app = adsk.core.Application.get();
  if (!app) throw Error("No asdk.core.Application.");

  let importManager = app.importManager
  let importOptions = importManager.createSTEPImportOptions("inputFile.step")
  let doc = importManager.importToNewDocument(importOptions)

  const design = doc.products.itemByProductType(
    "DesignProductType",
  ) as adsk.fusion.Design;

  let exportManager = design.exportManager
  let exportOptions = exportManager.createSTEPExportOptions("outputFile.step")
  exportManager.execute(exportOptions)

  adsk.result = JSON.stringify({message: "Created outputFile.stp"});

  while (app.hasActiveJobs) {
    wait(2000);
  }
}

function wait(ms: number) {
  const start = new Date().getTime();
  while (new Date().getTime() - start < ms) adsk.doEvents();
}

run();
