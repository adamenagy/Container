import adsk.core
import os
import json

import adsk.fusion
from ...lib import fusionAddInUtils as futil
from ... import config
app = adsk.core.Application.get()
ui = app.userInterface


# TODO *** Specify the command identity information. ***
CMD_ID = f'{config.COMPANY_NAME}_{config.ADDIN_NAME}_cmdUpload'
CMD_NAME = 'Upload to URL'
CMD_Description = 'A Fusion Add-in Command using HTTP'

# Specify that the command will be promoted to the panel.
IS_PROMOTED = True

# TODO *** Define the location where the command button will be created. ***
# This is done by specifying the workspace, the tab, and the panel, and the 
# command it will be inserted beside. Not providing the command to position it
# will insert it at the end.
WORKSPACE_ID = 'FusionSolidEnvironment'
PANEL_ID = 'SolidScriptsAddinsPanel'
COMMAND_BESIDE_ID = 'ScriptsManagerCommand'

# Resource location for command icons, here we assume a sub folder in this directory named "resources".
ICON_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', '')

# Local list of event handlers used to maintain a reference so
# they are not released and garbage collected.
local_handlers = []

opened_files = []


# Executed when add-in is run.
def start():
    # Create a command Definition.
    cmd_def = ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_Description, ICON_FOLDER)

    # Define an event handler for the command created event. It will be called when the button is clicked.
    futil.add_handler(cmd_def.commandCreated, command_created)
    
	# Define an event handler for the fusion360 protocol event. 
	# It will be called when the fusion360 protocol is used fom a website to open a file.
    futil.add_handler(app.openedFromURL, application_openedFromURL, local_handlers=local_handlers)

    # ******** Add a button into the UI so the user can run the command. ********
    # Get the target workspace the button will be created in.
    workspace = ui.workspaces.itemById(WORKSPACE_ID)

    # Get the panel the button will be created in.
    panel = workspace.toolbarPanels.itemById(PANEL_ID)

    # Create the button command control in the UI after the specified existing command.
    control = panel.controls.addCommand(cmd_def, COMMAND_BESIDE_ID, False)

    # Specify if the command is promoted to the main toolbar. 
    control.isPromoted = IS_PROMOTED


# Executed when add-in is stopped.
def stop():
    # Get the various UI elements for this command
    workspace = ui.workspaces.itemById(WORKSPACE_ID)
    panel = workspace.toolbarPanels.itemById(PANEL_ID)
    command_control = panel.controls.itemById(CMD_ID)
    command_definition = ui.commandDefinitions.itemById(CMD_ID)

    # Delete the button command control
    if command_control:
        command_control.deleteMe()

    # Delete the command definition
    if command_definition:
        command_definition.deleteMe()


# Function that is called when a user clicks the corresponding button in the UI.
# This defines the contents of the command dialog and connects to the command related events.
def command_created(args: adsk.core.CommandCreatedEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Created Event')

    # TODO Connect to the events that are needed by this command.
    futil.add_handler(args.command.execute, command_execute, local_handlers=local_handlers)


# This event handler is called when the user clicks the OK button in the command dialog or 
# is immediately called after the created event not command inputs were created for the dialog.
def command_execute(args: adsk.core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Execute Event')

    file_name = export_to_step()

    upload_file(file_name)


def export_to_step():
    # get active design        
    product = app.activeProduct
    design = adsk.fusion.Design.cast(product)
        
    # get the script location
    script_dir = os.path.dirname(os.path.realpath(__file__))   
    file_name = script_dir + "/temp.step"     
        
    # create a single exportManager instance
    export_mgr = design.exportManager

    # export the component with STP format
    stp_options = export_mgr.createSTEPExportOptions(file_name)
    export_mgr.execute(stp_options)

    return file_name


def upload_file(file_name):
    info = get_info()

    request = adsk.core.HttpRequest.create('https://webhook.site/e69467c9-9dba-4115-ac5f-fe5a7affde9f', adsk.core.HttpMethods.PostMethod)
    with open(file_name, 'r') as file:
        request.data = file.read()
    request.setHeader('Content-Type', 'application/text')
    request.setHeader('Authorization', f'Bearer {info["access_token"]}')
    res = request.executeSync()
    
    futil.log(f'HTTP request statusCode = {res.statusCode}')
     

# Event handler for the openedFromURL event.
def application_openedFromURL(args: adsk.core.WebRequestEventArgs):
    # Code to react to the event.
    app.log('In application_openedFromURL event handler.')
    
    doc = adsk.fusion.FusionDocument.cast(args.occurrenceOrDocument)
    
    opened_files.append({
    	"info": json.loads(args.privateInfo),
        "file": args.file,
        "doc": doc
	})
    
def get_info():
    for opened_file in opened_files:
        if opened_file["doc"] == app.activeDocument:
            return opened_file["info"]