var viewer;

launchViewer2();


function loadModel(viewer, urn) {
  function onDocumentLoadSuccess(doc) {
      var bubble = doc.getRoot();
      var items = bubble.search({ type: 'geometry', role: '2d' });
      var options1 = {};
      var Rmat = new THREE.Matrix4();
      Rmat.makeRotationZ(90 * Math.PI / 180);
      options1.placementTransform = Rmat;
      options1.keepCurrentModels = true;
      var options2 = { };
      viewer.loadDocumentNode(doc, items[1], options2);
      viewer.loadDocumentNode(doc, items[0], options1);
  }
  function onDocumentLoadFailure(code, message) {
      alert('Could not load model. See the console for more details.');
      console.error(message);
  }
  Autodesk.Viewing.Document.load(urn, onDocumentLoadSuccess, onDocumentLoadFailure);
}


function launchViewer4() {
  var options = {
    env: 'Local'
  };

  Autodesk.Viewing.Initializer(options, () => {
    viewer = new Autodesk.Viewing.GuiViewer3D(
      document.getElementById('forgeViewer'), {}
    );
    
    viewer.start();

    //var mx = new THREE.Matrix4();
    //mx.makeRotationZ(90 * Math.PI / 180);
    viewer.loadModel("scissors1.pdf", {page: 1}, (model1) => {
      //var bb = model1.getBoundingBox();
      //var mx = new THREE.Matrix4();
      //mx.makeRotationZ(90 * Math.PI / 180);
      // translation along X axis
      //mx.elements[12] = bb.max.y;
      //model1.setPlacementTransform(mx);

      viewer.loadModel("scissors2.pdf", {page: 1, keepCurrentModels: true}, async (model2) => {
        const pcExt = await viewer.loadExtension('Autodesk.Viewing.PixelCompare');
        pcExt.compareTwoModels(model1, model2);
      });
    });
  });
}

function launchViewer3() {
  var options = {
    env: 'Local',
    useADP: false
  };

  Autodesk.Viewing.Initializer(options, () => {
    viewer = new Autodesk.Viewing.GuiViewer3D(
      document.getElementById('forgeViewer'), {}
    );
    
    viewer.start();

    //var mx = new THREE.Matrix4();
    //mx.makeRotationZ(90 * Math.PI / 180);

    
    //viewer.loadExtension('Autodesk.PDF').then(function(ext) {
      //ext.renderPage(1)

    // Original URL is: http://127.0.0.1:5500/index.html?page=2
    // we change it to page=1
    // This should change the URL content without a reload
    //history.pushState('', '', 'index.html?page=2');
    viewer.loadModel("AutoCAD_Sample_Part1.pdf", viewer, (model) => {
        //await viewer.
        //ext.renderPage(1)
        //let hlc = viewer.toolController
      
        //ext.hyperlinkTracker.changePage(1)  


        //var bb = model1.getBoundingBox(); 
        //var mx = new THREE.Matrix4();
        //mx.makeRotationZ(90 * Math.PI / 180);
        // translation along X axis
        //mx.elements[12] = bb.max.y;
        //model1.setPlacementTransform(mx);

       
        // viewer.loadModel("AutoCAD_Sample_Part1.pdf", {page: 2, keepCurrentModels: true}, async (model2) => {
        //   const pcExt = await viewer.loadExtension('Autodesk.Viewing.PixelCompare');
        //   //pcExt.compareTwoModels(model1, model2);
        // });
         
      });
      
    })
  //});
}





function launchViewer2() {
  var options = {
    env: 'Local'
  };

  Autodesk.Viewing.Initializer(options, () => {
    viewer = new Autodesk.Viewing.GuiViewer3D(
      document.getElementById('forgeViewer'), {}
    );
    
    viewer.start(); 

    // Load 2 sheets
    viewer.loadModel('scissors2.pdf', {}, (model1) => {
      viewer.loadModel('scissors1.pdf', {}, async (model2) => {
        // Compare them 
        const cpExt = await viewer.loadExtension('Autodesk.Viewing.PixelCompare');
        cpExt.compareTwoModels(model1, model2);
      });
    });
  });
}

function launchViewer() {
  var options = {
    env: 'Local'
  };

  Autodesk.Viewing.Initializer(options, () => {
    viewer = new Autodesk.Viewing.GuiViewer3D(
      document.getElementById('forgeViewer'), {}
    );
    
    viewer.start();

    // Load 2 sheets
viewer.loadModel('scissors2.pdf', {}, (model) => {
  var bb = model.getBoundingBox();
  var mx = new THREE.Matrix4();
  mx.makeRotationZ(90 * Math.PI / 180);
  // translation along X axis
  mx.elements[12] = 1;
  mx.elements[13] = 1 - bb.max.x;
  model.setPlacementTransform(mx);
  //viewer.impl.invalidate(tre, true, false);
});
  });
}

function onDocumentLoadSuccess(doc) {
  var viewables = doc.getRoot().getDefaultGeometry();
  
  viewer.loadDocumentNode(doc, viewables).then(i => {
    // documented loaded, any action?
  });
  
 //viewer.loadModel('AutoCAD_Sample_Part1.pdf');
}

function onDocumentLoadFailure(viewerErrorCode) {
  console.error('onDocumentLoadFailure() - errorCode:' + viewerErrorCode);
}


