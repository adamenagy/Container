﻿''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Copyright (c) Autodesk, Inc. All rights reserved
' Written by Forge Partner Development
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted,
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Imports System
Imports System.Diagnostics
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports Inventor

Namespace TestPlugin
    <Guid("a3d7cf91-5628-40f5-a9b0-65e8a5ba9825")>
    Public Class PluginServer
        Implements ApplicationAddInServer

        Private _Automation As Object
        ' Inventor application object.
        Private _inventorServer As InventorServer

        Public Property Automation As Object Implements ApplicationAddInServer.Automation
            Get
                Return _Automation
            End Get
            Private Set(ByVal value As Object)
                _Automation = value
            End Set
        End Property

        Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
            Trace.TraceInformation(": TestPlugin (" & Assembly.GetExecutingAssembly().GetName().Version.ToString(4) & "): initializing... ")

            ' Initialize AddIn members.
            _inventorServer = addInSiteObject.InventorServer
            Automation = New SampleAutomation(_inventorServer)
        End Sub

        Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
            Trace.TraceInformation(": TestPlugin: deactivating... ")

            ' Release objects.
            Marshal.ReleaseComObject(_inventorServer)
            _inventorServer = Nothing
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Sub

        Public Sub ExecuteCommand(ByVal CommandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
            ' obsolete
        End Sub
    End Class
End Namespace
