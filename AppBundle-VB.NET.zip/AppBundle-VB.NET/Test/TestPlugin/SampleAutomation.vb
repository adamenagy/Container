﻿''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Copyright (c) Autodesk, Inc. All rights reserved
' Written by Forge Partner Development
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted,
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Imports System
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports System.Collections.Generic
Imports Inventor
Imports Autodesk.Forge.DesignAutomation.Inventor.Utils
Imports Autodesk.Forge.DesignAutomation.Inventor.Utils.Helpers

Namespace TestPlugin
    <ComVisible(True)>
    Public Class SampleAutomation
        Private ReadOnly inventorApplication As InventorServer

        Public Sub New(ByVal inventorApp As InventorServer)
            inventorApplication = inventorApp
        End Sub

        Public Sub Run(ByVal doc As Document)
            LogTrace("Run called with {0}", doc.DisplayName)
        End Sub

        Public Sub RunWithArguments(ByVal doc As Document, ByVal map As NameValueMap)
            LogTrace("Processing " & doc.FullFileName)

            Try
                ' Using NameValueMapExtension
                If map.HasKey("intIndex") Then
                    Dim intValue As Integer = map.AsInt("intIndex")
                    LogTrace($"Value of intIndex is: {intValue}")
                End If

                If map.HasKey("stringCollectionIndex") Then
                    Dim strCollection As IEnumerable(Of String) = map.AsStringCollection("stringCollectionIndex")

                    For Each strValue In strCollection
                        LogTrace($"String value is: {strValue}")
                    Next
                End If

                If doc.DocumentType = DocumentTypeEnum.kPartDocumentObject Then
                    Using New HeartBeat()
                        ' TODO: handle the Inventor part here
                    End Using
                ElseIf doc.DocumentType = DocumentTypeEnum.kAssemblyDocumentObject Then ' Assembly.

                    Using New HeartBeat()
                        ' TODO: handle the Inventor assembly here
                    End Using
                End If

            Catch e As Exception
                LogError("Processing failed. " & e.ToString())
            End Try
        End Sub

#Region "Logging utilities"

        ''' <summary>
        ''' Log message with 'trace' log level.
        ''' </summary>
        Private Shared Sub LogTrace(ByVal format As String, ParamArray args As Object())
            Trace.TraceInformation(format, args)
        End Sub

        ''' <summary>
        ''' Log message with 'trace' log level.
        ''' </summary>
        Private Shared Sub LogTrace(ByVal message As String)
            Trace.TraceInformation(message)
        End Sub

        ''' <summary>
        ''' Log message with 'error' log level.
        ''' </summary>
        Private Shared Sub LogError(ByVal format As String, ParamArray args As Object())
            Trace.TraceError(format, args)
        End Sub

        ''' <summary>
        ''' Log message with 'error' log level.
        ''' </summary>
        Private Shared Sub LogError(ByVal message As String)
            Trace.TraceError(message)
        End Sub

#End Region
    End Class
End Namespace
