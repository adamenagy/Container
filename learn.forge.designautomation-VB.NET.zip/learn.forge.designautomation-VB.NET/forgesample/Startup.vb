﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.AspNetCore.Hosting
Imports Microsoft.AspNetCore.Mvc
Imports Microsoft.Extensions.DependencyInjection

Namespace forgeSample
    Public Class Startup
        ' This method gets called by the runtime. Use this method to add services to the container.
        ' For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        Public Sub ConfigureServices(ByVal services As IServiceCollection)
            services.AddMvc(Sub(options) options.EnableEndpointRouting = False).SetCompatibilityVersion(CompatibilityVersion.Version_3_0).AddNewtonsoftJson()
            services.AddSignalR()
        End Sub

        ' This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        Public Sub Configure(ByVal app As IApplicationBuilder, ByVal env As IWebHostEnvironment)
            app.UseRouting()
            app.UseEndpoints(Sub(routes) routes.MapHub(Of Controllers.DesignAutomationHub)("/api/signalr/designautomation"))
            app.UseFileServer()
            app.UseMvc()
        End Sub
    End Class
End Namespace
