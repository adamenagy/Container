﻿''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Copyright (c) Autodesk, Inc. All rights reserved
' Written by Forge Partner Development
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted,
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Imports Autodesk.Forge
Imports Autodesk.Forge.DesignAutomation
Imports Autodesk.Forge.DesignAutomation.Model
Imports Autodesk.Forge.Model
Imports Microsoft.AspNetCore.Hosting
Imports Microsoft.AspNetCore.Http
Imports Microsoft.AspNetCore.Mvc
Imports Microsoft.AspNetCore.SignalR
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports RestSharp
Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports Activity = Autodesk.Forge.DesignAutomation.Model.Activity
Imports [Alias] = Autodesk.Forge.DesignAutomation.Model.Alias
Imports AppBundle = Autodesk.Forge.DesignAutomation.Model.AppBundle
Imports Parameter = Autodesk.Forge.DesignAutomation.Model.Parameter
Imports WorkItem = Autodesk.Forge.DesignAutomation.Model.WorkItem
Imports WorkItemStatus = Autodesk.Forge.DesignAutomation.Model.WorkItemStatus

Namespace forgeSample.Controllers
    <ApiController>
    Public Class DesignAutomationController
        Inherits ControllerBase
        ' Used to access the application folder (temp location for files & bundles)
        Private _env As IWebHostEnvironment
        ' used to access the SignalR Hub
        Private _hubContext As IHubContext(Of DesignAutomationHub)
        ' Local folder for bundles
        Public ReadOnly Property LocalBundlesFolder As String
            Get
                Return Path.Combine(_env.WebRootPath, "bundles")
            End Get
        End Property
        ''' Prefix for AppBundles and Activities
        Public Shared ReadOnly Property NickName As String
            Get
                Return OAuthController.GetAppSetting("FORGE_CLIENT_ID")
            End Get
        End Property
        ''' Alias for the app (e.g. DEV, STG, PROD). This value may come from an environment variable
        Public Shared ReadOnly Property [Alias] As String
            Get
                Return "dev"
            End Get
        End Property
        ' Design Automation v3 API
        Private _designAutomation As DesignAutomationClient

        ' Constructor, where env and hubContext are specified
        Public Sub New(ByVal env As IWebHostEnvironment, ByVal hubContext As IHubContext(Of DesignAutomationHub), ByVal api As DesignAutomationClient)
            _designAutomation = api
            _env = env
            _hubContext = hubContext
        End Sub

        ''' <summary>
        ''' Get all Activities defined for this account
        ''' </summary>
        <HttpGet>
        <Route("api/forge/designautomation/activities")>
        Public Async Function GetDefinedActivities() As Task(Of List(Of String))
            ' filter list of 
            Dim activities As Page(Of String) = Await _designAutomation.GetActivitiesAsync()
            Dim definedActivities As List(Of String) = New List(Of String)()

            For Each act In activities.Data
                If act.StartsWith(NickName) AndAlso act.IndexOf("$LATEST") = -1 Then definedActivities.Add(act.Replace(NickName & ".", String.Empty))
            Next

            Return definedActivities
        End Function

        ''' <summary>
        ''' Define a new activity
        ''' </summary>
        <HttpPost>
        <Route("api/forge/designautomation/activities")>
        Public Async Function CreateActivity(
        <FromBody> ByVal activitySpecs As JObject) As Task(Of IActionResult)
            ' basic input validation
            Dim zipFileName As String = activitySpecs("zipFileName").Value(Of String)()
            Dim engineName As String = activitySpecs("engine").Value(Of String)()

            ' standard name for this sample
            Dim appBundleName = zipFileName & "AppBundle"
            Dim activityName = zipFileName & "Activity"

            ' 
            Dim activities As Page(Of String) = Await _designAutomation.GetActivitiesAsync()
            Dim qualifiedActivityId = String.Format("{0}.{1}+{2}", NickName, activityName, [Alias])

            If Not activities.Data.Contains(qualifiedActivityId) Then
                ' define the activity
                ' ToDo: parametrize for different engines...
                Dim engineAttributes As Object = Me.EngineAttributes(engineName)
                Dim commandLine = String.Format(engineAttributes.commandLine, appBundleName)
                Dim activitySpec As Activity = New Activity() With {
                    .Id = activityName,
                    .Appbundles = New List(Of String)() From {
                        String.Format("{0}.{1}+{2}", NickName, appBundleName, [Alias])
                    },
                    .CommandLine = New List(Of String)() From {
                        commandLine
                    },
                    .Engine = engineName,
                    .Parameters = New Dictionary(Of String, Parameter)() From {
                        {"inputFile", New Parameter() With {
                            .Description = "input file",
                            .LocalName = "$(inputFile)",
                            .Ondemand = False,
                            .Required = True,
                            .Verb = Verb.Get,
                            .Zip = False
                        }},
                        {"inputJson", New Parameter() With {
                            .Description = "input json",
                            .LocalName = "params.json",
                            .Ondemand = False,
                            .Required = False,
                            .Verb = Verb.Get,
                            .Zip = False
                        }},
                        {"outputFile", New Parameter() With {
                            .Description = "output file",
                            .LocalName = "outputFile." & engineAttributes.extension,
                            .Ondemand = False,
                            .Required = True,
                            .Verb = Verb.Put,
                            .Zip = False
                        }}
                    },
                    .Settings = New Dictionary(Of String, ISetting)() From {
                        {"script", New StringSetting() With {
                            .Value = engineAttributes.script
                        }}
                    }
                }
                Dim newActivity = Await _designAutomation.CreateActivityAsync(activitySpec)

                ' specify the alias for this Activity
                Dim aliasSpec As [Alias] = New [Alias]() With {
                    .Id = [Alias],
                    .Version = 1
                }
                Dim newAlias = Await _designAutomation.CreateActivityAliasAsync(activityName, aliasSpec)
                Return MyBase.Ok(New With {
                    .Activity = qualifiedActivityId
                })
            End If

            ' as this activity points to a AppBundle "dev" alias (which points to the last version of the bundle),
            ' there is no need to update it (for this sample), but this may be extended for different contexts
            Return MyBase.Ok(New With {
                .Activity = "Activity already defined"
            })
        End Function

        ''' <summary>
        ''' Helps identify the engine
        ''' </summary>
        Private Function EngineAttributes(ByVal engine As String) As Object
            If engine.Contains("3dsMax") Then Return New With {
                .commandLine = "$(engine.path)\3dsmaxbatch.exe -sceneFile ""$(args[inputFile].path)"" $(settings[script].path)",
                .extension = "max",
                .script = "da = dotNetClass(""Autodesk.Forge.Sample.DesignAutomation.Max.RuntimeExecute"")" & vbLf & "da.ModifyWindowWidthHeight()" & vbLf
            }
            If engine.Contains("AutoCAD") Then Return New With {
                .commandLine = "$(engine.path)\accoreconsole.exe /i ""$(args[inputFile].path)"" /al ""$(appbundles[{0}].path)"" /s $(settings[script].path)",
                .extension = "dwg",
                .script = "UpdateParam" & vbLf
            }
            If engine.Contains("Inventor") Then Return New With {
                .commandLine = "$(engine.path)\inventorcoreconsole.exe /i ""$(args[inputFile].path)"" /al ""$(appbundles[{0}].path)""",
                .extension = "ipt",
                .script = String.Empty
            }
            If engine.Contains("Revit") Then Return New With {
                .commandLine = "$(engine.path)\revitcoreconsole.exe /i ""$(args[inputFile].path)"" /al ""$(appbundles[{0}].path)""",
                .extension = "rvt",
                .script = String.Empty
            }
            Throw New Exception("Invalid engine")
        End Function

        ''' <summary>
        ''' Define a new appbundle
        ''' </summary>
        <HttpPost>
        <Route("api/forge/designautomation/appbundles")>
        Public Async Function CreateAppBundle(
        <FromBody> ByVal appBundleSpecs As JObject) As Task(Of IActionResult)
            ' basic input validation
            Dim zipFileName As String = appBundleSpecs("zipFileName").Value(Of String)()
            Dim engineName As String = appBundleSpecs("engine").Value(Of String)()

            ' standard name for this sample
            Dim appBundleName = zipFileName & "AppBundle"

            ' check if ZIP with bundle is here
            Dim packageZipPath = Path.Combine(LocalBundlesFolder, zipFileName & ".zip")
            If Not IO.File.Exists(packageZipPath) Then Throw New Exception("Appbundle not found at " & packageZipPath)

            ' get defined app bundles
            Dim appBundles As Page(Of String) = Await _designAutomation.GetAppBundlesAsync()

            ' check if app bundle is already define
            Dim newAppVersion As Object
            Dim qualifiedAppBundleId = String.Format("{0}.{1}+{2}", NickName, appBundleName, [Alias])

            If Not appBundles.Data.Contains(qualifiedAppBundleId) Then
                ' create an appbundle (version 1)
                Dim appBundleSpec As AppBundle = New AppBundle() With {
                    .Package = appBundleName,
                    .Engine = engineName,
                    .Id = appBundleName,
                    .Description = String.Format("Description for {0}", appBundleName)
                }
                newAppVersion = Await _designAutomation.CreateAppBundleAsync(appBundleSpec)
                If newAppVersion Is Nothing Then Throw New Exception("Cannot create new app")

                ' create alias pointing to v1
                Dim aliasSpec As [Alias] = New [Alias]() With {
                    .Id = [Alias],
                    .Version = 1
                }
                Dim newAlias = Await _designAutomation.CreateAppBundleAliasAsync(appBundleName, aliasSpec)
            Else
                ' create new version
                Dim appBundleSpec As AppBundle = New AppBundle() With {
                    .Engine = engineName,
                    .Description = appBundleName
                }
                newAppVersion = Await _designAutomation.CreateAppBundleVersionAsync(appBundleName, appBundleSpec)
                If newAppVersion Is Nothing Then Throw New Exception("Cannot create new version")

                ' update alias pointing to v+1
                Dim aliasSpec As AliasPatch = New AliasPatch() With {
                    .Version = newAppVersion.Version
                }
                Dim newAlias = Await _designAutomation.ModifyAppBundleAliasAsync(appBundleName, [Alias], aliasSpec)
            End If

            ' upload the zip with .bundle
            Dim uploadClient As RestClient = New RestClient(CType(newAppVersion.UploadParameters.EndpointURL, String))
            Dim request As RestRequest = New RestRequest(String.Empty, Method.POST)
            request.AlwaysMultipartFormData = True

            For Each x As KeyValuePair(Of String, String) In newAppVersion.UploadParameters.FormData
                request.AddParameter(x.Key, x.Value)
            Next

            request.AddFile("file", packageZipPath)
            request.AddHeader("Cache-Control", "no-cache")
            Await uploadClient.ExecuteTaskAsync(request)
            Return MyBase.Ok(New With {
                .AppBundle = qualifiedAppBundleId,
                newAppVersion.Version
            })
        End Function

        ''' <summary>
        ''' Input for StartWorkitem
        ''' </summary>
        Public Class StartWorkitemInput
            Public Property inputFile As IFormFile
            Public Property data As String
        End Class

        ''' <summary>
        ''' Start a new workitem
        ''' </summary>
        <HttpPost>
        <Route("api/forge/designautomation/workitems")>
        Public Async Function StartWorkitem(
        <FromForm> ByVal input As StartWorkitemInput) As Task(Of IActionResult)
            ' basic input validation
            Dim workItemData = JObject.Parse(input.data)
            Dim widthParam As String = workItemData("width").Value(Of String)()
            Dim heigthParam As String = workItemData("height").Value(Of String)()
            Dim activityName As String = String.Format("{0}.{1}", NickName, workItemData("activityName").Value(Of String)())
            Dim browerConnectionId As String = workItemData("browerConnectionId").Value(Of String)()

            ' save the file on the server
            Dim fileSavePath = Path.Combine(_env.ContentRootPath, Path.GetFileName(input.inputFile.FileName))

            Using stream = New FileStream(fileSavePath, FileMode.Create)
                Await input.inputFile.CopyToAsync(stream)
            End Using

            ' OAuth token
            Dim oauth As Object = Await OAuthController.GetInternalAsync()

            ' upload file to OSS Bucket
            ' 1. ensure bucket existis
            Dim bucketKey As String = NickName.ToLower() & "-designautomation"
            Dim buckets As BucketsApi = New BucketsApi()
            buckets.Configuration.AccessToken = oauth.access_token

            Try
                Dim bucketPayload As PostBucketsPayload = New PostBucketsPayload(bucketKey, Nothing, PostBucketsPayload.PolicyKeyEnum.Transient)
                Await buckets.CreateBucketAsync(bucketPayload, "US")
            Catch
            End Try ' in case bucket already exists
            ' 2. upload inputFile
            Dim inputFileNameOSS = String.Format("{0}_input_{1}", Date.Now.ToString("yyyyMMddhhmmss"), Path.GetFileName(input.inputFile.FileName)) ' avoid overriding
            Dim objects As ObjectsApi = New ObjectsApi()
            objects.Configuration.AccessToken = oauth.access_token

            Using streamReader As StreamReader = New StreamReader(fileSavePath)
                Await objects.UploadObjectAsync(bucketKey, inputFileNameOSS, CInt(streamReader.BaseStream.Length), streamReader.BaseStream, "application/octet-stream")
            End Using

            IO.File.Delete(fileSavePath) ' delete server copy

            ' prepare workitem arguments
            ' 1. input file
            Dim inputFileArgument As XrefTreeArgument = New XrefTreeArgument() With {
                .Url = String.Format("https://developer.api.autodesk.com/oss/v2/buckets/{0}/objects/{1}", bucketKey, inputFileNameOSS),
                .Headers = New Dictionary(Of String, String)() From {
                    {"Authorization", "Bearer " & oauth.access_token}
                }
            }
            ' 2. input json
            Dim inputJson As Object = New JObject()
            inputJson.Width = widthParam
            inputJson.Height = heigthParam
            Dim inputJsonArgument As XrefTreeArgument = New XrefTreeArgument() With {
                .Url = "data:application/json, " & CType(inputJson, JObject).ToString(Formatting.None).Replace("""", "'")
            }
            ' 3. output file
            Dim outputFileNameOSS = String.Format("{0}_output_{1}", Date.Now.ToString("yyyyMMddhhmmss"), Path.GetFileName(input.inputFile.FileName)) ' avoid overriding
            Dim outputFileArgument As XrefTreeArgument = New XrefTreeArgument() With {
                .Url = String.Format("https://developer.api.autodesk.com/oss/v2/buckets/{0}/objects/{1}", bucketKey, outputFileNameOSS),
                .Verb = Verb.Put,
                .Headers = New Dictionary(Of String, String)() From {
                    {"Authorization", "Bearer " & oauth.access_token}
                }
            }

            ' prepare & submit workitem
            Dim callbackUrl = String.Format("{0}/api/forge/callback/designautomation?id={1}&outputFileName={2}", OAuthController.GetAppSetting("FORGE_WEBHOOK_URL"), browerConnectionId, outputFileNameOSS)
            Dim workItemSpec As WorkItem = New WorkItem() With {
                .ActivityId = activityName,
                .Arguments = New Dictionary(Of String, IArgument)() From {
                    {"inputFile", inputFileArgument},
                    {"inputJson", inputJsonArgument},
                    {"outputFile", outputFileArgument},
                    {"onComplete", New XrefTreeArgument With {
                        .Verb = Verb.Post,
                        .Url = callbackUrl
                    }}
                }
            }
            Dim workItemStatus = Await _designAutomation.CreateWorkItemAsync(workItemSpec)
            Return MyBase.Ok(New With {
                .WorkItemId = workItemStatus.Id
            })
        End Function

        ''' <summary>
        ''' Callback from Design Automation Workitem (onProgress or onComplete)
        ''' </summary>
        <HttpPost>
        <Route("/api/forge/callback/designautomation")>
        Public Async Function OnCallback(ByVal id As String, ByVal outputFileName As String,
        <FromBody> ByVal body As Object) As Task(Of IActionResult)
            Try
                ' your webhook should return immediately! we can use Hangfire to schedule a job
                Dim bodyJson As JObject = JObject.Parse(CStr(body.ToString()))
                Await _hubContext.Clients.Client(id).SendAsync("onComplete", bodyJson.ToString())
                Dim client = New RestClient(bodyJson("reportUrl").Value(Of String)())
                Dim request = New RestRequest(String.Empty)
                Dim bs = client.DownloadData(request)
                Dim report = Encoding.Default.GetString(bs)
                Await _hubContext.Clients.Client(id).SendAsync("onComplete", report)
                Dim objectsApi As ObjectsApi = New ObjectsApi()
                Dim signedUrl As Object = Await objectsApi.CreateSignedResourceAsyncWithHttpInfo(NickName.ToLower() & "-designautomation", outputFileName, New PostBucketsSigned(10), "read")
                Await _hubContext.Clients.Client(CStr(id)).SendAsync("downloadResult", CStr(signedUrl.Data.signedUrl))
            Catch e As Exception
            End Try

            ' ALWAYS return ok (200)
            Return MyBase.Ok()
        End Function

        ''' <summary>
        ''' Return a list of available engines
        ''' </summary>
        <HttpGet>
        <Route("api/forge/designautomation/engines")>
        Public Async Function GetAvailableEngines() As Task(Of List(Of String))
            Dim oauth As Object = Await OAuthController.GetInternalAsync()

            ' define Engines API
            Dim engines As Page(Of String) = Await _designAutomation.GetEnginesAsync()
            engines.Data.Sort()
            Return engines.Data ' return list of engines
        End Function

        ''' <summary>
        ''' Clear the accounts (for debugging purposes)
        ''' </summary>
        <HttpDelete>
        <Route("api/forge/designautomation/account")>
        Public Async Function ClearAccount() As Task(Of IActionResult)
            ' clear account
            Await _designAutomation.DeleteForgeAppAsync("me")
            Return MyBase.Ok()
        End Function

        ''' <summary>
        ''' Names of app bundles on this project
        ''' </summary>
        <HttpGet>
        <Route("api/appbundles")>
        Public Function GetLocalBundles() As String()
            ' this folder is placed under the public folder, which may expose the bundles
            ' but it was defined this way so it be published on most hosts easily
            Return Directory.GetFiles(LocalBundlesFolder, "*.zip").[Select](New Func(Of String, String)(AddressOf Path.GetFileNameWithoutExtension)).ToArray()
        End Function
    End Class

    ''' <summary>
    ''' Class uses for SignalR
    ''' </summary>
    Public Class DesignAutomationHub
        Inherits Microsoft.AspNetCore.SignalR.Hub

        Public Function GetConnectionId() As String
            Return Context.ConnectionId
        End Function
    End Class
End Namespace
