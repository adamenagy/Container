﻿''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
' Copyright (c) Autodesk, Inc. All rights reserved
' Written by Forge Partner Development
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted,
' provided that the above copyright notice appears in all copies and
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC.
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

Imports System
Imports System.Threading.Tasks
Imports Microsoft.AspNetCore.Mvc
Imports Autodesk.Forge

Namespace forgeSample.Controllers
    <ApiController>
    Public Class OAuthController
        Inherits ControllerBase
        ' As both internal & public tokens are used for all visitors
        ' we don't need to request a new token on every request, so let's
        ' cache them using static variables. Note we still need to refresh
        ' them after the expires_in time (in seconds)
        Private Shared Property InternalToken As Object

        ''' <summary>
        ''' Get access token with internal (write) scope
        ''' </summary>
        Public Shared Async Function GetInternalAsync() As Task(Of Object)
            If InternalToken Is Nothing OrElse InternalToken.ExpiresAt < Date.UtcNow Then
                InternalToken = Await Get2LeggedTokenAsync(New Scope() {Scope.BucketCreate, Scope.BucketRead, Scope.BucketDelete, Scope.DataRead, Scope.DataWrite, Scope.DataCreate, Scope.CodeAll})
                InternalToken.ExpiresAt = Date.UtcNow.AddSeconds(InternalToken.expires_in)
            End If

            Return InternalToken
        End Function

        ''' <summary>
        ''' Get the access token from Autodesk
        ''' </summary>
        Private Shared Async Function Get2LeggedTokenAsync(ByVal scopes As Scope()) As Task(Of Object)
            Dim oauth As TwoLeggedApi = New TwoLeggedApi()
            Dim grantType = "client_credentials"
            Dim bearer As Object = Await oauth.AuthenticateAsync(GetAppSetting("FORGE_CLIENT_ID"), GetAppSetting("FORGE_CLIENT_SECRET"), grantType, scopes)
            Return bearer
        End Function

        ''' <summary>
        ''' Reads appsettings from web.config
        ''' </summary>
        Public Shared Function GetAppSetting(ByVal settingKey As String) As String
            Return Environment.GetEnvironmentVariable(settingKey).Trim()
        End Function
    End Class
End Namespace
