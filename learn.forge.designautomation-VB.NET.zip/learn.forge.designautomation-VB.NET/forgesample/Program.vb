﻿Imports Microsoft.AspNetCore
Imports Microsoft.AspNetCore.Hosting
Imports Autodesk.Forge.Core
Imports Autodesk.Forge.DesignAutomation

Namespace forgeSample.Controllers
    Public Class Program
        Public Shared Sub Main(ByVal args As String())
            CreateHostBuilder(args).ConfigureAppConfiguration(Sub(builder) builder.AddForgeAlternativeEnvironmentVariables()).ConfigureServices(Sub(hostContext, services) services.AddDesignAutomation(hostContext.Configuration)).Build().Run()
        End Sub

        Public Shared Function CreateHostBuilder(ByVal args As String()) As IWebHostBuilder
            Return WebHost.CreateDefaultBuilder(args).UseStartup(Of Startup)()
        End Function
    End Class
End Namespace
