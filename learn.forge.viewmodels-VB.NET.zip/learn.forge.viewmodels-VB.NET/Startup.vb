﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.AspNetCore.Hosting
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.AspNetCore.Mvc
Imports Microsoft.Extensions.Hosting

Namespace forgeSample
    Public Class Startup
        ' This method gets called by the runtime. Use this method to add services to the container.
        ' For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        Public Sub ConfigureServices(ByVal services As IServiceCollection)
            services.AddMvc(Sub(options) options.EnableEndpointRouting = False).SetCompatibilityVersion(CompatibilityVersion.Version_3_0).AddNewtonsoftJson()
        End Sub

        ' This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        Public Sub Configure(ByVal app As IApplicationBuilder, ByVal env As IWebHostEnvironment)
            If env.IsDevelopment() Then
                app.UseDeveloperExceptionPage()
            End If

            app.UseDefaultFiles()
            app.UseStaticFiles()
            app.UseMvc()
        End Sub
    End Class
End Namespace
