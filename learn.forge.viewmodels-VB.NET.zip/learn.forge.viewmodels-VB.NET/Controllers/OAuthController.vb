﻿Imports Autodesk.Forge
Imports Microsoft.AspNetCore.Mvc
Imports System
Imports System.Threading.Tasks

Namespace forgeSample.Controllers
    <ApiController>
    Public Class OAuthController
        Inherits ControllerBase
        ' As both internal & public tokens are used for all visitors
        ' we don't need to request a new token on every request, so let's
        ' cache them using static variables. Note we still need to refresh
        ' them after the expires_in time (in seconds)
        Private Shared Property InternalToken As Object
        Private Shared Property PublicToken As Object

        ''' <summary>
        ''' Get access token with public (viewables:read) scope
        ''' </summary>
        <HttpGet>
        <Route("api/forge/oauth/token")>
        Public Async Function GetPublicAsync() As Task(Of Object)
            If PublicToken Is Nothing OrElse PublicToken.ExpiresAt < Date.UtcNow Then
                PublicToken = Await Get2LeggedTokenAsync(New Scope() {Scope.ViewablesRead})
                PublicToken.ExpiresAt = Date.UtcNow.AddSeconds(PublicToken.expires_in)
            End If

            Return PublicToken
        End Function

        ''' <summary>
        ''' Get access token with internal (write) scope
        ''' </summary>
        Public Shared Async Function GetInternalAsync() As Task(Of Object)
            If InternalToken Is Nothing OrElse InternalToken.ExpiresAt < Date.UtcNow Then
                InternalToken = Await Get2LeggedTokenAsync(New Scope() {Scope.BucketCreate, Scope.BucketRead, Scope.BucketDelete, Scope.DataRead, Scope.DataWrite, Scope.DataCreate, Scope.CodeAll})
                InternalToken.ExpiresAt = Date.UtcNow.AddSeconds(InternalToken.expires_in)
            End If

            Return InternalToken
        End Function

        ''' <summary>
        ''' Get the access token from Autodesk
        ''' </summary>
        Private Shared Async Function Get2LeggedTokenAsync(ByVal scopes As Scope()) As Task(Of Object)
            Dim oauth As TwoLeggedApi = New TwoLeggedApi()
            Dim grantType = "client_credentials"
            Dim bearer As Object = Await oauth.AuthenticateAsync(GetAppSetting("FORGE_CLIENT_ID"), GetAppSetting("FORGE_CLIENT_SECRET"), grantType, scopes)
            Return bearer
        End Function

        ''' <summary>
        ''' Reads appsettings from web.config
        ''' </summary>
        Public Shared Function GetAppSetting(ByVal settingKey As String) As String
            Return Environment.GetEnvironmentVariable(settingKey).Trim()
        End Function
    End Class
End Namespace
