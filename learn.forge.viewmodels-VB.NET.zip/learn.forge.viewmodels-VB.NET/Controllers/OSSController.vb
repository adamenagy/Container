﻿Imports Autodesk.Forge
Imports Autodesk.Forge.Model
Imports Microsoft.AspNetCore.Hosting
Imports Microsoft.AspNetCore.Http
Imports Microsoft.AspNetCore.Mvc
Imports System.Collections.Generic
Imports System.IO
Imports System.Text
Imports System.Threading.Tasks

Namespace forgeSample.Controllers
    <ApiController>
    Public Class OSSController
        Inherits ControllerBase

        Private _env As IWebHostEnvironment

        Public Sub New(ByVal env As IWebHostEnvironment)
            _env = env
        End Sub

        Public ReadOnly Property ClientId As String
            Get
                Return OAuthController.GetAppSetting("FORGE_CLIENT_ID").ToLower()
            End Get
        End Property

        ''' <summary>
        ''' Return list of buckets (id=#) or list of objects (id=bucketKey)
        ''' </summary>
        <HttpGet>
        <Route("api/forge/oss/buckets")>
        Public Async Function GetOSSAsync(ByVal id As String) As Task(Of IList(Of TreeNode))
            Dim nodes As IList(Of TreeNode) = New List(Of TreeNode)()
            Dim oauth As Object = Await OAuthController.GetInternalAsync()

            Try


                If Equals(id, "#") Then ' root
                    ' in this case, let's return all buckets
                    Dim appBckets As BucketsApi = New BucketsApi()
                    appBckets.Configuration.AccessToken = oauth.access_token

                    ' to simplify, let's return only the first 100 buckets
                    Dim buckets = Await appBckets.GetBucketsAsync("US", 100)
                    Dim items As Object = buckets.Dictionary("items")
                    For Each bucket As Object In New DynamicDictionaryItems(items)
                        Dim bucketKey = bucket.Value.Dictionary("bucketKey")
                        nodes.Add(New TreeNode(bucketKey, bucketKey.Replace(ClientId & "-", String.Empty), "bucket", True))
                    Next
                Else
                    ' as we have the id (bucketKey), let's return all 
                    Dim objects As ObjectsApi = New ObjectsApi()
                    objects.Configuration.AccessToken = oauth.access_token
                    Dim objectsList = Await objects.GetObjectsAsync(id, 100)
                    Dim items As Object = objectsList.Dictionary("items")
                    For Each objInfo As KeyValuePair(Of String, Object) In New DynamicDictionaryItems(items)
                        Dim objectId = objInfo.Value.Dictionary("objectId")
                        Dim objectKey = objInfo.Value.Dictionary("objectKey")
                        nodes.Add(New TreeNode(OSSController.Base64Encode(CStr(objectId)), objectKey, "object", False))
                    Next
                End If
            Catch ex As Exception
                Dim x = ex
            End Try

            Return nodes
        End Function

        ''' <summary>
        ''' Model data for jsTree used on GetOSSAsync
        ''' </summary>
        Public Class TreeNode
            Public Sub New(ByVal id As String, ByVal text As String, ByVal type As String, ByVal children As Boolean)
                Me.id = id
                Me.text = text
                Me.type = type
                Me.children = children
            End Sub

            Public Property id As String
            Public Property text As String
            Public Property type As String
            Public Property children As Boolean
        End Class

        ''' <summary>
        ''' Create a new bucket 
        ''' </summary>
        <HttpPost>
        <Route("api/forge/oss/buckets")>
        Public Async Function CreateBucket(
        <FromBody> ByVal bucket As CreateBucketModel) As Task(Of Object)
            Dim buckets As BucketsApi = New BucketsApi()
            Dim token As Object = Await OAuthController.GetInternalAsync()
            buckets.Configuration.AccessToken = token.access_token
            Dim bucketPayload As PostBucketsPayload = New PostBucketsPayload(String.Format("{0}-{1}", ClientId, bucket.bucketKey.ToLower()), Nothing, PostBucketsPayload.PolicyKeyEnum.Transient)
            Return Await buckets.CreateBucketAsync(bucketPayload, "US")
        End Function

        ''' <summary>
        ''' Input model for CreateBucket method
        ''' </summary>
        Public Class CreateBucketModel
            Public Property bucketKey As String
        End Class

        ''' <summary>
        ''' Receive a file from the client and upload to the bucket
        ''' </summary>
        ''' <returns></returns>
        <HttpPost>
        <Route("api/forge/oss/objects")>
        Public Async Function UploadObject(
        <FromForm> ByVal input As UploadFile) As Task(Of Object)
            ' save the file on the server
            Dim fileSavePath = Path.Combine(_env.WebRootPath, Path.GetFileName(input.fileToUpload.FileName))

            Using stream = New FileStream(fileSavePath, FileMode.Create)
                Await input.fileToUpload.CopyToAsync(stream)
            End Using


            ' get the bucket...
            Dim oauth As Object = Await OAuthController.GetInternalAsync()
            Dim objects As ObjectsApi = New ObjectsApi()
            objects.Configuration.AccessToken = oauth.access_token

            ' upload the file/object, which will create a new object
            Dim uploadedObj As Object

            Using streamReader As StreamReader = New StreamReader(fileSavePath.ToString())
                uploadedObj = Await objects.UploadObjectAsync(input.bucketKey, Path.GetFileName(input.fileToUpload.FileName), CInt(streamReader.BaseStream.Length), streamReader.BaseStream, "application/octet-stream")
            End Using

            ' cleanup
            IO.File.Delete(fileSavePath)
            Return uploadedObj
        End Function

        Public Class UploadFile
            Public Property bucketKey As String
            Public Property fileToUpload As IFormFile
        End Class

        ''' <summary>
        ''' Base64 enconde a string
        ''' </summary>
        Public Shared Function Base64Encode(ByVal plainText As String) As String
            Dim plainTextBytes = Encoding.UTF8.GetBytes(plainText)
            Return Convert.ToBase64String(plainTextBytes)
        End Function
    End Class
End Namespace
