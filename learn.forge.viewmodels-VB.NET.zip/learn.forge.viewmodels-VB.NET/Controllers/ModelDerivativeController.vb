﻿Imports Autodesk.Forge
Imports Autodesk.Forge.Model
Imports Microsoft.AspNetCore.Mvc
Imports System.Collections.Generic
Imports System.Threading.Tasks

Namespace forgeSample.Controllers
    <ApiController>
    Public Class ModelDerivativeController
        Inherits ControllerBase
        ''' <summary>
        ''' Start the translation job for a give bucketKey/objectName
        ''' </summary>
        ''' <paramname="objModel"></param>
        ''' <returns></returns>
        <HttpPost>
        <Route("api/forge/modelderivative/jobs")>
        Public Async Function TranslateObject(
        <FromBody> ByVal objModel As TranslateObjectModel) As Task(Of Object)
            Dim oauth As Object = Await OAuthController.GetInternalAsync()

            ' prepare the payload
            Dim outputs As List(Of JobPayloadItem) = New List(Of JobPayloadItem)() From {
                New JobPayloadItem(JobPayloadItem.TypeEnum.Svf, New List(Of JobPayloadItem.ViewsEnum)() From {
                    JobPayloadItem.ViewsEnum._2d,
                    JobPayloadItem.ViewsEnum._3d
                })
            }
            Dim job As JobPayload
            job = New JobPayload(New JobPayloadInput(objModel.objectName), New JobPayloadOutput(outputs))

            ' start the translation
            Dim derivative As DerivativesApi = New DerivativesApi()
            derivative.Configuration.AccessToken = oauth.access_token
            Dim jobPosted As Object = Await derivative.TranslateAsync(job)
            Return jobPosted
        End Function

        ''' <summary>
        ''' Model for TranslateObject method
        ''' </summary>
        Public Class TranslateObjectModel
            Public Property bucketKey As String
            Public Property objectName As String
        End Class
    End Class
End Namespace
